package com.cg.card.dao;

import java.util.List;

import com.cg.card.bean.CardBean;

public interface ICardDao {

	List<CardBean> getAllDetails();

	CardBean getDetail(String panNumber);

}
