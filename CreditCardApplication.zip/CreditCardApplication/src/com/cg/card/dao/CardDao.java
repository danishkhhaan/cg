package com.cg.card.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.card.bean.CardBean;


@Repository
public class CardDao implements ICardDao {
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public List<CardBean> getAllDetails() {
		TypedQuery<CardBean> query = entityManager.createQuery("SELECT d FROM CardBean d", CardBean.class);
		return query.getResultList();
	}
	@Override
	public CardBean getDetail(String panNumber) {
		return entityManager.find(CardBean.class, panNumber);
	}
	
}
