package com.cg.card.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.card.bean.CardBean;
import com.cg.card.service.ICardService;

@Controller
public class CardController {
	
	@Autowired
	private ICardService service;
	
	@RequestMapping("/showFirstPage")
	public String showFirstPage() {
		return "index";
	}
	
	@RequestMapping("/showViewAll")
	public ModelAndView showViewAll() {

		ModelAndView mv = new ModelAndView();

		List<CardBean> list = service.getAllDetails();
		if (list.isEmpty()) {
			//String msg = "There is no request for credit cards";
			mv.addObject("msg", "There is no request for credit cards");
			mv.setViewName("myError");
		} else {
			mv.setViewName("viewAll");
			mv.addObject("list", list);
		}
		return mv;
	}
	
	@SuppressWarnings("unused")
	@RequestMapping("/retrieveDetail")
	public ModelAndView retrieveDetail (@RequestParam("panNumber") String panNumber ) {
	
		System.out.println(panNumber);
		ModelAndView mv = new ModelAndView();
		
		CardBean bean = new CardBean();
		bean = service.getDetail(panNumber);
		if (bean!=null) {
			mv.setViewName("particularDetails");
			mv.addObject("bean", bean);
		} else {
			mv.setViewName("myError");
			mv.addObject("msg", "Select a valid pan number");
		}
		return mv;
		
	}

	
	}
	

