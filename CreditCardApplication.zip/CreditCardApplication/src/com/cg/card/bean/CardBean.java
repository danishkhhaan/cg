package com.cg.card.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CardBean {
	@Id
	private String panNumber;
	private String bankName;
	private String accountType;
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	@Override
	public String toString() {
		return "CardBean [panNumber=" + panNumber + ", bankName=" + bankName
				+ ", accountType=" + accountType + "]";
	}
}
