package com.cg.card.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.card.bean.CardBean;
import com.cg.card.dao.ICardDao;


@Service
public class CardService implements ICardService {

	@Autowired
	 ICardDao cardDao;

	@Override
	public List<CardBean> getAllDetails() {
		return cardDao.getAllDetails();
	}

	@Override
	public CardBean getDetail(String panNumber) {
		return cardDao.getDetail(panNumber);
	}

}
