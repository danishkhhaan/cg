package com.cg.card.service;

import java.util.List;

import com.cg.card.bean.CardBean;

public interface ICardService {

	List<CardBean> getAllDetails();

	CardBean getDetail(String panNumber);

}
