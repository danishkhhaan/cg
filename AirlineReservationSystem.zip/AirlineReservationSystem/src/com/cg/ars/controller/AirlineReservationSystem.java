package com.cg.ars.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.ars.dto.AirportDTO;
import com.cg.ars.dto.BookingInfoDTO;
import com.cg.ars.dto.CustomerDTO;
import com.cg.ars.dto.FlightInfoDTO;
import com.cg.ars.dto.UserDTO;
import com.cg.ars.exception.AirlineException;
import com.cg.ars.service.AirlineServiceImpl;
import com.cg.ars.service.IAirlineService;

/**
 * Servlet implementation class AirlineReservationSystem
 */
@WebServlet(name="/AirlineReservationSystem",
		urlPatterns={"/AirlineReservationSystem","/UserSignUp","/SignUp","/UserLogin","/ValidateLogin",
		             "/UserTicketBooking","/UserBooking","/BookTicket","/ValidatePayment","/UserHome",
		             "/ViewBooking","/DeleteBooking","/DeleteUserBooking","/ViewAirports","/AirportDetails","/LogOut","/AboutUs","/AuthorityLogin",
		             "/ValidateAuthority","/UpdateFlightInfo","/InsertFlight","/InsertFlightDetails",
		             "/AdminHomePage","RemoveFlight","/FlightRemoval","/UpdateFlightSchedule","/ViewFlightSchedule",
		             "/ViewAllFlights","/ViewParticularFlight","/FlightIdSchedule","/ChangeFlightSchedule",
		             "/EditFlightSchedule","/UpdateFlightDetails","/GenerateReports","/PassengerList","/PassengerListReport",
		             "/BookingList","/BookingListReport","/FlightListBasedOnSrcCity","/SrcCityReport","/FlightListBasedOnDestCity",
		             "/DestCityReport","/FlightListBasedOnDeptDate","/DeptDateReport","/FlightListBasedOnArrDate","/ArrDateReport",
		             "/ViewFlightOccupancyDate","/ViewOccupancyDate","/ViewFlightOccupancyCity","/ViewOccupancyCity","/ExecutiveHomePage","/Faq"})
public class AirlineReservationSystem extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AirlineReservationSystem() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String path = request.getServletPath();
		String targetPath = null;
		RequestDispatcher reqDispatch;
		UserDTO user;
		FlightInfoDTO flight;
		CustomerDTO customer;
		BookingInfoDTO book;
		IAirlineService service;
		HttpSession session = request.getSession();	
 		
		if("/AirlineReservationSystem".equalsIgnoreCase(path))
		{  
			targetPath = "/pages/home.jsp";
		}
		if("/UserSignUp".equalsIgnoreCase(path))
		{
			targetPath = "/pages/signUp.jsp";
		}
		if("/SignUp".equalsIgnoreCase(path))
		{
		customer = new CustomerDTO();
		customer.setFirstName(request.getParameter("fName"));
		customer.setLastName(request.getParameter("lName"));
		customer.setUserName(request.getParameter("username"));
		customer.setEmail(request.getParameter("email"));
		customer.setPhoneNo(Long.parseLong(request.getParameter("phoneNo")));
		session.setAttribute("customer", customer);
		service = new AirlineServiceImpl();
		
		try 
		{
			if(service.isAvailableUsername(customer))
			{ 
				session.setAttribute("username", request.getParameter("username"));
				/*session.setAttribute("phoneNo", customer.getPhoneNo());*/
				
				
			}
			else
			{
				request.setAttribute("usernameTaken", "User name is already used");
				targetPath = "/pages/signUp.jsp";
			}
		} catch (AirlineException e) 
		{
			request.setAttribute("error", e.getMessage());
			targetPath = "/pages/error.jsp";
		}
			user = new UserDTO();
			user.setUserName((String)session.getAttribute("username"));
			user.setPassword(request.getParameter("password"));
			/*user.setMobileNo((Long)session.getAttribute("phoneNo"));*/
			String password = request.getParameter("re-password");
			
			if(!user.getPassword().equals(password))
			{
				request.setAttribute("passwordMismatch", "Passwords don't match");
				targetPath = "/pages/signUp.jsp";
			}
			else
			{
				service = new AirlineServiceImpl();
				customer = (CustomerDTO) session.getAttribute("customer");
				try 
				{
					if(service.isAvailableUsername(customer))
					{
						session.setAttribute("username", customer.getUserName());
						session.setAttribute("phoneNo", customer.getPhoneNo());
						
					 if(service.addNewPassenger(customer, user))
					{   
						 request.setAttribute("SuccessfullSignUp", "You are successfully Registered"); 
						targetPath = "/pages/user.jsp";
						session.setAttribute("username", user.getUserName());
						System.out.println(user.getUserName());
					}
				 }else
					{
						request.setAttribute("usernameTaken", "User name is already used");
						targetPath = "/pages/signUp.jsp";
					}
			  }
				catch (AirlineException e) 
				{
					request.setAttribute("error", e.getMessage());
					targetPath = "/pages/error.jsp";
				}
			}		
		
	}
		if("/UserLogin".equalsIgnoreCase(path))
		{
			targetPath="/pages/userLogin.jsp";
		}
		if("/ValidateLogin".equalsIgnoreCase(path))
		{
			user = new UserDTO();
			user.setUserName(request.getParameter("username"));
			user.setPassword(request.getParameter("password"));
			service = new AirlineServiceImpl();
			
			try 
			{
				String userName =user.getUserName();
				String pwd=user.getPassword();
				
				if(service.isValidUser(user))
				{	
					if(userName.equals("ravindra") && pwd.equals("Ravindra@123"))
					{
						targetPath = "/pages/admin.jsp";
					}
					else if(userName.equals("chowdary") && pwd.equals("Ravindra@123"))
					{
						targetPath = "/pages/executive.jsp";
					}
				
					else 
					{
						targetPath = "/pages/user.jsp";
						session.setAttribute("username", user.getUserName());
			    	}
			   }		
				else
				{
					request.setAttribute("passengerLoginFailed", "Invalid login credentials");
					targetPath = "/pages/userLogin.jsp";
				}
						
			}
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		if("/UserTicketBooking".equalsIgnoreCase(path))
		{
			if(session.getAttribute("username")==null)
			{
				request.setAttribute("signUpBeforeBooking", "Please sign-up or login before booking.");
				targetPath = "/pages/signUp.jsp";
			}
			else
			{
				service = new AirlineServiceImpl();
				List<String> deptCityList = new ArrayList<String>();
				List<String> arrCityList = new ArrayList<String>();
				try 
				{
					deptCityList = service.findDepartureCities();
					session.setAttribute("deptCityList", deptCityList);
					
					arrCityList = service.findArrivalCities();
					session.setAttribute("arrCityList", arrCityList);
					
					targetPath = "/pages/bookingOptions.jsp";
				}
				catch (AirlineException e)
				{
					request.setAttribute("error", e.getMessage());
					targetPath = "/pages/error.jsp";
				}
			}
		}
		
		if("/UserBooking".equalsIgnoreCase(path))
		{
            flight = new FlightInfoDTO();
			
			String deptCity = request.getParameter("deptCity");
			String arrCity = request.getParameter("arrCity");
			String deptDate = request.getParameter("deptDate");
						
			if(deptCity.equals(arrCity))
			{
				request.setAttribute("deptArrCity", "Departure and arrival cities are the same.");
				targetPath = "/pages/bookingOptions.jsp";
			}
			else if(deptCity!=arrCity)
			{
				session.setAttribute("deptCity", deptCity);
				session.setAttribute("arrCity", arrCity);
				List<FlightInfoDTO> flightList = new ArrayList<FlightInfoDTO>();
				service = new AirlineServiceImpl();
				
				try 
				{
					flightList = service.searchFlightDetails(deptCity, arrCity, deptDate);
					if(flightList.isEmpty())
					{
						request.setAttribute("noFlights", "No Flights Available. Try again.");
						targetPath = "/pages/bookingOptions.jsp";
					}
					else
					{
						session.setAttribute("searchFlightList", flightList);
						targetPath = "/pages/bookingPage.jsp";
					}
				} 
				catch (AirlineException e)
				{
					request.setAttribute("error", e.getMessage());
					targetPath = "/pages/error.jsp";
				}
			}else
			{
				System.out.println("");
			}
		}
		
		if("/BookTicket".equalsIgnoreCase(path))
		{
			String flightNo = request.getParameter("flightNo");
			String seatType = request.getParameter("seatType");
			int noOfPassengers = Integer.parseInt(request.getParameter("NoOfPassengers"));

			service = new AirlineServiceImpl();
		
			try
			{
				if(service.isSeatAvailable(flightNo, seatType,noOfPassengers ))
				{
					book = new BookingInfoDTO();
					book.setFlightNo(flightNo);
					book.setClassType(seatType);				
					book.setNoOfPassengers(noOfPassengers);
					book.setSrcCity((String)session.getAttribute("deptCity"));
					book.setDestCity((String)session.getAttribute("arrCity"));
					
					String username = (String) session.getAttribute("username");
					String emailId = service.getCustomerMail(username);
					book.setCustMail(emailId);
					
					String custName = service.getCustomerName(username);
					book.setCustName(custName);
					
					float totalFare = service.getTotalFare(flightNo, seatType, noOfPassengers);
					book.setTotalFare(totalFare);
					
					session.setAttribute("book", book);
					
					targetPath = "/pages/bookingPayment.jsp";
					
				}
				else
				{
					request.setAttribute("unavailableSeats", "Seats are unavailable. Try again");
					targetPath = "/pages/bookingPage.jsp";
				}
			} 
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}	
		}
		if("/ValidatePayment".equalsIgnoreCase(path))
		{
			book = (BookingInfoDTO) session.getAttribute("book");
			book.setCreditCardInfo(request.getParameter("creditInfo"));
			service = new AirlineServiceImpl();
			BookingInfoDTO bb=new BookingInfoDTO();
			try 
			{
				bb = service.bookFlight(book);
				String bookingId=bb.getBookingId();
				int seatNo=bb.getSeatNo();
				session.setAttribute("bookingId", bookingId);
				session.setAttribute("seatNo", seatNo );
				service.updateSeatNum(book);
				targetPath = "/pages/bookingId.jsp";
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/UserHome".equalsIgnoreCase(path))
		{
			targetPath="/pages/user.jsp";
		}
		
		if("/ViewBooking".equalsIgnoreCase(path))
		{
			service = new AirlineServiceImpl();
			List<BookingInfoDTO> bookingInfoList;
			String username = (String) session.getAttribute("username");
			
			try 
			{
				bookingInfoList = service.getCustomerBookingInfo(username);
				
				if(!bookingInfoList.isEmpty())
				{
					session.setAttribute("bookingInfoList", bookingInfoList);
					
					targetPath = "/pages/bookingInfo.jsp";
				}
				else
				{
					request.setAttribute("noBooking", "You haven't booked any flight yet.");
					targetPath = "/pages/user.jsp";
				}
				
			} 
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.pages";
			}
		}
		if("/DeleteUserBooking".equalsIgnoreCase(path))
		{
			 PrintWriter out=response.getWriter();
				service = new AirlineServiceImpl();
				String username = (String) session.getAttribute("username");
				String bookingId = request.getParameter("bookingId");
				
				try 
				{
					if(service.isValidBookingId(bookingId, username))
					{	
						if(service.updateFlightSeats(bookingId))
						{
							if(service.deleteCustomerBooking(bookingId))
							{
								request.setAttribute("successfulDelete", "Booking successfully deleted.");
								targetPath = "/pages/user.jsp";
								
							}
						}
						else
						{
							request.setAttribute("updationError", "Error while updating your request. Try again.");
							targetPath = "/pages/bookingIdAccept.jsp";
						}
					}
					else
					{
						request.setAttribute("invalidBookingId", "Invalid Booking Id. Please try again.");
						targetPath = "/pages/bookingIdAccept.jsp";
					}
				}
				catch (AirlineException e)
				{
					request.setAttribute("error", e.getMessage());
					targetPath = "/pages/error.jsp";
				}
				
		}
		if("/DeleteBooking".equalsIgnoreCase(path))
		{
			targetPath = "/pages/bookingIdAccept.jsp";
		}	
		if("/ViewAirports".equalsIgnoreCase(path))
		{
			targetPath="/pages/abbrevation.jsp";
			
		}
		if("/AirportDetails".equalsIgnoreCase(path))
		{

			String abb = request.getParameter("abbrevation");
			
			service = new AirlineServiceImpl();
			List<AirportDTO> airportList = new ArrayList<AirportDTO>();
			
			try 
			{
				airportList = service.viewAirports(abb);
			  if(airportList.isEmpty())
				{
					request.setAttribute("noAirports", "No airports with given abbrevation");
					targetPath = "/pages/abbrevation.jsp";
				}
				else
				{
					request.setAttribute("airportList", airportList);
					targetPath = "/pages/airportDetails.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}		
		}
		if("/LogOut".equalsIgnoreCase(path))
		{
			targetPath="/pages/home.jsp";
		}
		
		if("/AboutUs".equalsIgnoreCase(path))
		{  
			targetPath="/pages/aboutus.jsp";
		}
		
		if("/AuthorityLogin".equalsIgnoreCase(path))
		{
			targetPath = "/pages/authorityLogin.jsp";
		}
		if("/ValidateAuthority".equalsIgnoreCase(path))
		{
			user = new UserDTO();
			user.setUserName(request.getParameter("username"));
			user.setPassword(request.getParameter("password"));
			user.setRole(request.getParameter("role"));
			service = new AirlineServiceImpl();
			
			try 
			{
				if(service.isValidAuthority(user))
				{
					session.setAttribute("username", user.getUserName());
					if(user.getRole().equals("administrator"))
						targetPath = "/pages/admin.jsp";
					else
						targetPath = "/pages/executive.jsp";
				}
					
				else
				{
					request.setAttribute("authorityLoginFailed", "Invalid login credentials");
					targetPath = "/pages/authorityLogin.jsp";
				}
						
			}
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
				
		}
		if("/UpdateFlightInfo".equalsIgnoreCase(path))
		{
			targetPath="/pages/updateFlightInfo.jsp";
		}
		
		if("/InsertFlight".equalsIgnoreCase(path))
		{
			targetPath = "/pages/insertFlight.jsp";
		}
		
		if("/InsertFlightDetails".equalsIgnoreCase(path))
		{
			service = new AirlineServiceImpl();
			String flightNo = request.getParameter("flightNo");
			String flightName = request.getParameter("flightName");
			String deptCity = request.getParameter("deptCity");
			String arrCity = request.getParameter("arrCity");
			String deptDate = request.getParameter("deptDate");
			String arrDate = request.getParameter("arrDate");
					
			String hours, minutes, seconds;
			hours = request.getParameter("deptTimeHr");
			minutes = request.getParameter("deptTimeMin");
			seconds = request.getParameter("deptTimeSec");
			if(hours.length() == 1)
				hours = "0"+hours;
			if(minutes.length() == 1)
				minutes = "0"+minutes;
			if(seconds.length() == 1)
				seconds = "0"+seconds;
			String deptTime = hours+":"+minutes+":"+seconds;
			
			hours = request.getParameter("arrTimeHr");
			minutes = request.getParameter("arrTimeMin");
			seconds = request.getParameter("arrTimeSec");
			if(hours.length() == 1)
				hours = "0"+hours;
			if(minutes.length() == 1)
				minutes = "0"+minutes;
			if(seconds.length() == 1)
				seconds = "0"+seconds;
			String arrTime = hours+":"+minutes+":"+seconds;
						
			String firstClassSeats = request.getParameter("firstClassSeats");
			String firstClassFare = request.getParameter("firstClassFare");
			String businessClassSeats = request.getParameter("businessClassSeats");
			String businessClassFare = request.getParameter("businessClassFare");
			
			try 
			{
				if(service.isAvailableFlightNo(flightNo))
				{
					request.setAttribute("flightExists", "Flight already exists. Try again.");
					targetPath = "/pages/insertFlight.jsp";
				}
				else if(deptCity.equals(arrCity))
				{
					request.setAttribute("srcDestCityEqual", "Source and destination cities cannot be equal. Try again.");
					targetPath = "/pages/insertFlight.jsp";
				}
				else if(deptDate.compareTo(arrDate) > 0)
				{
					request.setAttribute("deptGreaterThanArrDate", "Departure date cannot be greater than arrival date");
					targetPath = "/pages/insertFlight.jsp";
				}
				else if((deptDate.compareTo(arrDate) == 0) && (deptTime.compareTo(arrTime) >= 0))
				{
					request.setAttribute("deptGreaterThanArrTime", "Departure time cannot be greater than or equal to arrival time");
					targetPath = "/pages/insertFlight.jsp";
				}
				else
				{
					deptTime = deptDate+" "+deptTime;
					arrTime = arrDate+" "+arrTime;
					
					flight = new FlightInfoDTO();
					
					flight.setFlightNo(flightNo);
					flight.setAirLine(flightName);
					flight.setDeptCity(deptCity);
					flight.setArrCity(arrCity);
					flight.setDeptDate(deptDate);
					flight.setArrDate(arrDate);
					flight.setDeptTime(deptTime);
					flight.setArrTime(arrTime);
					flight.setFirstSeats(Integer.parseInt(firstClassSeats));
					flight.setFirstSeatFare(Float.parseFloat(firstClassFare));
					flight.setBussiSeats(Integer.parseInt(businessClassSeats));
					flight.setBussiSeatFare(Float.parseFloat(businessClassFare));
						
					if(service.insertFlightDetails(flight))
					{
						request.setAttribute("flight", flight);
						targetPath = "/pages/displayFlightDetails.jsp";
					}
					else
					{
						request.setAttribute("insertError", "Error while inserting details. Try again.");
						targetPath = "/pages/insertFlight.jsp";
					}
				}
			}
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/AdminHomePage".equalsIgnoreCase(path))
		{
			targetPath="/pages/admin.jsp";
		}
		
		
		if("/RemoveFlight".equalsIgnoreCase(path))
		{
			List<String> flightNoList = new ArrayList<String>();
			service = new AirlineServiceImpl();
			
			try 
			{
				flightNoList = service.getFlightNoList();
				if(flightNoList.isEmpty())
				{
					request.setAttribute("noFlightsAvailable", "No flights are available");
					targetPath = "/pages/updateFlightInfo.jsp";
				}
				else
				{
					session.setAttribute("flightNoList", flightNoList);
					targetPath = "/pages/RemoveFlight.jsp";
				}
			} 
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		if("/FlightRemoval".equalsIgnoreCase(path))
		{
			String flightNo = request.getParameter("flightNo");
			service = new AirlineServiceImpl();
			
			try 
			{
				if(service.deleteFlightDetails(flightNo))
					{
						request.setAttribute("flightDeletedSuccessfully", "Flight "+flightNo+" deleted successfully.");
						targetPath = "/pages/admin.jsp";
					}
					else
					{
						request.setAttribute("flightNotDeleted", "Could not delete the flight with "+flightNo);
						targetPath = "/pages/admin.jsp";
					}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}	
		}
		
		if("/UpdateFlightSchedule".equalsIgnoreCase(path))
		{
			targetPath = "/pages/updateFlightSchedule.jsp";
		}
		if("/ViewFlightSchedule".equalsIgnoreCase(path))
		{
			targetPath = "/pages/viewFlightSchedule.jsp";
		}
		
		if("/ViewAllFlights".equalsIgnoreCase(path))
		{
			service = new AirlineServiceImpl();
			List<FlightInfoDTO> flightScheduleList = new ArrayList<FlightInfoDTO>();
			
			try 
			{
				flightScheduleList = service.viewAllFlightSchedules();
			
				if(flightScheduleList.isEmpty())
				{
					request.setAttribute("noFlightSchedules", "No Flights Available. Try again.");
					targetPath = "/pages/viewFlightSchedule.jsp";
				}
				else
				{
					request.setAttribute("flightScheduleList", flightScheduleList);
					targetPath = "/pages/allFlights.jsp";
				}
			} 
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/ViewParticularFlight".equalsIgnoreCase(path))
		{
			List<String> flightNoList = new ArrayList<String>();
			service = new AirlineServiceImpl();
			
			try 
			{
				flightNoList = service.getFlightNoList();
				if(flightNoList.isEmpty())
				{
					request.setAttribute("noFlightsAvailable", "No flights are available");
					targetPath = "/pages/viewFlightSchedule.jsp";
				}
				else
				{
					session.setAttribute("flightNoList", flightNoList);
					targetPath = "/pages/viewParticularFlight.jsp";
				}
			} 
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/FlightIdSchedule".equalsIgnoreCase(path))
		{
			String flightNo = request.getParameter("flightNo");
			service = new AirlineServiceImpl();
					
			try 
			{
				flight = new FlightInfoDTO();
				flight = service.viewFlightSchedule(flightNo);
				request.setAttribute("flight", flight);
				targetPath = "/pages/flightScheduleOnId.jsp";
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/ChangeFlightSchedule".equalsIgnoreCase(path))
		{
			List<String> flightNoList = new ArrayList<String>();
			service = new AirlineServiceImpl();
			
			try 
			{
				flightNoList = service.getFlightNoList();
				if(flightNoList.isEmpty())
				{
					request.setAttribute("noFlightsAvailable", "No flights are available");
					targetPath = "/pages/updateFlightSchedule.jsp";
				}
				else
				{
					session.setAttribute("flightNoList", flightNoList);
					targetPath = "/pages/flightIdToUpdate.jsp";
				}
			} 
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/EditFlightSchedule".equalsIgnoreCase(path))
		{
			String flightNo = request.getParameter("flightNo");
			service = new AirlineServiceImpl();
					
			try 
			{
				flight = new FlightInfoDTO();
				flight = service.viewFlightSchedule(flightNo);
					
				session.setAttribute("flight", flight);
				targetPath = "/pages/changeFlightDetails.jsp";
				
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/UpdateFlightDetails".equalsIgnoreCase(path))
		{
			service = new AirlineServiceImpl();
			String flightNo = request.getParameter("flightNo");
			String flightName = request.getParameter("flightName");
			String deptCity = request.getParameter("deptCity");
			String arrCity = request.getParameter("arrCity");
			String deptDate = request.getParameter("deptDate");
			String arrDate = request.getParameter("arrDate");

			String hours, minutes, seconds;
			hours = request.getParameter("deptTimeHr");
			minutes = request.getParameter("deptTimeMin");
			seconds = request.getParameter("deptTimeSec");
			if(hours.length() == 1)
				hours = "0"+hours;
			if(minutes.length() == 1)
				minutes = "0"+minutes;
			if(seconds.length() == 1)
				seconds = "0"+seconds;
			String deptTime = hours+":"+minutes+":"+seconds;
			
			hours = request.getParameter("arrTimeHr");
			minutes = request.getParameter("arrTimeMin");
			seconds = request.getParameter("arrTimeSec");
			if(hours.length() == 1)
				hours = "0"+hours;
			if(minutes.length() == 1)
				minutes = "0"+minutes;
			if(seconds.length() == 1)
				seconds = "0"+seconds;
			String arrTime = hours+":"+minutes+":"+seconds;
			
			String firstClassSeats = request.getParameter("firstClassSeats");
			String firstClassFare = request.getParameter("firstClassFare");
			String businessClassSeats = request.getParameter("businessClassSeats");
			String businessClassFare = request.getParameter("businessClassFare");
			
			try 
			{
				if(deptCity.equals(arrCity))
				{
					request.setAttribute("srcDestCityEqual", "Source and destination cities cannot be equal. Try again.");
					targetPath = "/pages/changeFlightDetails.jsp";
				}
				else if(deptDate.compareTo(arrDate) > 0)
				{
					request.setAttribute("deptGreaterThanArrDate", "Departure date cannot be greater than arrival date");
					targetPath = "/pages/changeFlightDetails.jsp";
				}
				else if((deptDate.compareTo(arrDate) == 0) && (deptTime.compareTo(arrTime) >= 0))
				{
					request.setAttribute("deptGreaterThanArrTime", "Departure time cannot be greater than or equal to arrival time");
					targetPath = "/pages/changeFlightDetails.jsp";
				}
				else
				{
					deptTime = deptDate+" "+deptTime;
					arrTime = arrDate+" "+arrTime;
					
					flight = new FlightInfoDTO();
					
					flight.setFlightNo(flightNo);
					flight.setAirLine(flightName);
					flight.setDeptCity(deptCity);
					flight.setArrCity(arrCity);
					flight.setDeptDate(deptDate);
					flight.setArrDate(arrDate);
					flight.setDeptTime(deptTime);
					flight.setArrTime(arrTime);
					flight.setFirstSeats(Integer.parseInt(firstClassSeats));
					flight.setFirstSeatFare(Float.parseFloat(firstClassFare));
					flight.setBussiSeats(Integer.parseInt(businessClassSeats));
					flight.setBussiSeatFare(Float.parseFloat(businessClassFare));
						
					if(service.updateFlightDetails(flight))
					{  
						request.setAttribute("flight", flight);
						targetPath = "/pages/updateFlightDetails.jsp";
					}
					else
					{
						request.setAttribute("updateError", "Error while updating details. Try again.");
						targetPath = "/pages/updateFlightDetails.jsp";
					}
				}
			}
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/GenerateReports".equalsIgnoreCase(path))
		{
			targetPath="/pages/generateReports.jsp";
		}
		if("/PassengerList".equalsIgnoreCase(path))
		{
			List<String> flightNoList = new ArrayList<String>();
			service = new AirlineServiceImpl();
			
			try 
			{
				flightNoList = service.getFlightNoList();
				if(flightNoList.isEmpty())
				{
					request.setAttribute("noFlightsAvailable", "No flights are available");
					targetPath = "/pages/generateReports.jsp";
				}
				else
				{System.out.println("pass2");
					session.setAttribute("flightNoList", flightNoList);
					targetPath = "/pages/flightIdPassengerList.jsp";
				}
			} 
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		if("/PassengerListReport".equalsIgnoreCase(path))
		{
			String flightNo = request.getParameter("flightNo");
			service = new AirlineServiceImpl();
					
			try 
			{
				List<CustomerDTO> passengerList = new ArrayList<CustomerDTO>();
				passengerList = service.getPassengerList(flightNo);
					
				if(passengerList.isEmpty())
				{ 
					request.setAttribute("noFlightsBooked", "No tickets have been booked in the flight "+flightNo);
					targetPath = "/pages/flightIdPassengerList.jsp";
				}
				else
				{
					request.setAttribute("flightNo", flightNo);
					request.setAttribute("passengerList", passengerList);
					targetPath = "/pages/passengerListReport.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/BookingList".equalsIgnoreCase(path))
		{
			List<String> flightNoList = new ArrayList<String>();
			service = new AirlineServiceImpl();
			
			try 
			{
				flightNoList = service.getFlightNoList();
				if(flightNoList.isEmpty())
				{
					request.setAttribute("noFlightsAvailable", "No flights are available");
					targetPath = "/pages/generateReports.jsp";
				}
				else
				{
					session.setAttribute("flightNoList", flightNoList);
					targetPath = "/pages/flightIdBookingList.jsp";
				}
			} 
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/BookingListReport".equalsIgnoreCase(path))
		{
			String flightNo = request.getParameter("flightNo");
			service = new AirlineServiceImpl();
					
			try 
			{
				List<BookingInfoDTO> bookingList = new ArrayList<BookingInfoDTO>();
				bookingList = service.getBookingList(flightNo);
				
				if(bookingList.isEmpty())
				{
					request.setAttribute("noFlightsBooked", "No flights have been booked in the flight "+flightNo);
					targetPath = "/pages/flightIdBookingList.jsp";
				}
				else
				{
					request.setAttribute("flightNo", flightNo);
					request.setAttribute("bookingList", bookingList);
					targetPath = "/pages/bookingListReport.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/FlightListBasedOnSrcCity".equalsIgnoreCase(path))
		{
			service = new AirlineServiceImpl();
			List<String> srcCityList = new ArrayList<String>();
			
			try 
			{
				srcCityList = service.findDepartureCities();
				if(srcCityList.isEmpty())
				{
					request.setAttribute("noFlights", "No flights to show");
					targetPath = "/pages/generateReports.jsp";
				}
				else
				{
					request.setAttribute("srcCityList", srcCityList);
					targetPath = "/pages/chooseSourceCity.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
			

		if("/SrcCityReport".equalsIgnoreCase(path))
		{
			String srcCity = request.getParameter("srcCityList");
			service = new AirlineServiceImpl();
			List<FlightInfoDTO> flightList = new ArrayList<FlightInfoDTO>();
			
			try 
			{
				flightList = service.viewFlightScheduleSrcCity(srcCity);
				if(flightList.isEmpty())
				{
					request.setAttribute("noFlightsBooked", "No flights have been booked from the source city "+srcCity);
					targetPath = "/pages/chooseSourceCity.jsp";
				}
				else
				{
					request.setAttribute("flightList", flightList);
					targetPath = "/pages/flightsBasedOnSrcCity.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}	
		}
		
		if("/FlightListBasedOnDestCity".equalsIgnoreCase(path))
		{
			service = new AirlineServiceImpl();
			List<String> destCityList = new ArrayList<String>();
			try 
			{
				destCityList = service.findArrivalCities();
				if(destCityList.isEmpty())
				{
					request.setAttribute("noFlights", "No flights to show");
					targetPath = "/pages/generateReports.jsp";
				}
				else
				{
					request.setAttribute("destCityList", destCityList);
					targetPath = "/pages/chooseDestCity.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/DestCityReport".equalsIgnoreCase(path))
		{
			String destCity = request.getParameter("destCity");
			service = new AirlineServiceImpl();
			List<FlightInfoDTO> flightList = new ArrayList<FlightInfoDTO>();
			
			try 
			{
				flightList = service.viewFlightScheduleDestCity(destCity);
				if(flightList.isEmpty())
				{
					request.setAttribute("noFlightsBooked", "No flights have been booked to the destination city "+destCity);
					targetPath = "/pages/chooseDestCity.jsp";
				}
				else
				{
					request.setAttribute("flightList", flightList);
					targetPath = "/pages/flightsBasedOnDestCity.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}	
		}
		if("/FlightListBasedOnDeptDate".equalsIgnoreCase(path))
		{
			targetPath = "/pages/chooseDeptDate.jsp";
		}
		if("/faq".equalsIgnoreCase(path))
		{
			targetPath="/pages/faq.jsp";
		}
		if("/DeptDateReport".equalsIgnoreCase(path))
		{
			String deptDate = request.getParameter("deptDate");
			service = new AirlineServiceImpl();
			List<FlightInfoDTO> flightList = new ArrayList<FlightInfoDTO>();
			
			try 
			{
				flightList = service.viewFlightScheduleDeptDate(deptDate);
				if(flightList.isEmpty())
				{
					request.setAttribute("noFlights", "No flights available on the date "+deptDate);
					targetPath = "/pages/chooseDeptDate.jsp";
				}
				else
				{
					request.setAttribute("flightList", flightList);
					targetPath = "/pages/flightDetailsReport.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}	
		}

		if("/FlightListBasedOnArrDate".equalsIgnoreCase(path))
		{
			targetPath = "/pages/chooseArrDate.jsp";
		}
		
		if("/ArrDateReport".equalsIgnoreCase(path))
		{
			String arrDate = request.getParameter("arrDate");
			service = new AirlineServiceImpl();
			List<FlightInfoDTO> flightList = new ArrayList<FlightInfoDTO>();
			
			try 
			{
				flightList = service.viewFlightScheduleArrDate(arrDate);
				if(flightList.isEmpty())
				{
					request.setAttribute("noFlights", "No flights available on the date "+arrDate);
					targetPath = "/pages/chooseArrDate.jsp";
				}
				else
				{
					request.setAttribute("flightList", flightList);
					targetPath = "/pages/flightDetailsReport.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		if("/ViewFlightOccupancyDate".equalsIgnoreCase(path))
		{
			targetPath = "/pages/flightOccupancyDate.jsp";
		}
		
		if(("/ViewOccupancyDate").equalsIgnoreCase(path))
		{
			String deptDate = request.getParameter("deptDate");
			String arrDate = request.getParameter("arrDate");
			List<String> flightNoList = new ArrayList<String>();
			List<BookingInfoDTO> occupancyList = new ArrayList<BookingInfoDTO>();
			service = new AirlineServiceImpl();
			
			if(deptDate.compareTo(arrDate) <= 0)
			{
				try 
				{
					flightNoList = service.flightNoListDate(deptDate, arrDate);
					if(flightNoList.isEmpty())
					{
						request.setAttribute("noFlightsAvailable", "No flights available. Please try again.");
						targetPath = "/pages/flightOccupancyDate.jsp";
					}
					else
					{
						occupancyList = service.viewFlightOccupancy(flightNoList);
						if(occupancyList.isEmpty())
						{
							request.setAttribute("noFlightsBooked", "No flights booked. Please try again.");
							targetPath = "/pages/flightOccupancyDate.jsp";
						}
						else
						{
							request.setAttribute("occupancyList", occupancyList);
							targetPath = "/pages/flightOccupancyList.jsp";
						}
					}
				} 
				catch (AirlineException e) 
				{
					request.setAttribute("error", e.getMessage());
					targetPath = "/pages/error.jsp";
				}
			}
			else
			{
				request.setAttribute("deptGreaterThanArr", "Departure date cannot be greater than arrival date");
				targetPath = "/pages/flightOccupancyDate.jsp";
			}
		}
		
		if("/ViewFlightOccupancyCity".equalsIgnoreCase(path))
		{
			service = new AirlineServiceImpl();
			List<String> deptCityList = new ArrayList<String>();
			List<String> arrCityList = new ArrayList<String>();
			try 
			{
				deptCityList = service.findDepartureCities();
				session.setAttribute("deptCityList", deptCityList);
				arrCityList = service.findArrivalCities();
				session.setAttribute("arrCityList", arrCityList);
				targetPath = "/pages/flightOccupancyCity.jsp";
			}
			catch(AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/ViewOccupancyCity".equalsIgnoreCase(path))
		{
			String srcCity = request.getParameter("deptCity");
			String destCity = request.getParameter("arrCity");
			service = new AirlineServiceImpl();
			List<String> flightNoList = new ArrayList<String>();
			List<BookingInfoDTO> occupancyList = new ArrayList<BookingInfoDTO>();
			
			if(!srcCity.equals(destCity))
			{
				try 
				{
					flightNoList = service.flightNoListCity(srcCity, destCity);
					if(flightNoList.isEmpty())
					{
						request.setAttribute("noFlightsAvailable", "No flights available. Please try again.");
						targetPath = "/pages/flightOccupancyCity.jsp";
					}
					else
					{
						occupancyList = service.viewFlightOccupancy(flightNoList);
						if(occupancyList.isEmpty())
						{
							request.setAttribute("noFlightsBooked", "No flights booked. Please try again.");
							targetPath = "/pages/flightOccupancyCity.jsp";
						}
						else
						{
							request.setAttribute("occupancyList", occupancyList);
							targetPath = "/pages/flightOccupancyList.jsp";
						}
					}
				} 
				catch (AirlineException e) 
				{
					request.setAttribute("error", e.getMessage());
					targetPath = "/pages/error.jsp";
				}
			}
			else
			{
				request.setAttribute("srcDestCity", "Source and destination cities can not be same.");
				targetPath = "/pages/flightOccupancyCity.jsp";
			}
			
		}
		if("/ExecutiveHomePage".equalsIgnoreCase(path))
		{
			targetPath="/pages/executive.jsp";
		}
		reqDispatch = getServletContext().getRequestDispatcher(targetPath);
		reqDispatch.forward(request, response);
 }
}
