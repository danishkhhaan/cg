package com.cg.ars.service;

import java.util.List;

import com.cg.ars.dao.AirlineReservationDAOImpl;
import com.cg.ars.dto.AirportDTO;
import com.cg.ars.dto.BookingInfoDTO;
import com.cg.ars.dto.CustomerDTO;
import com.cg.ars.dto.FlightInfoDTO;
import com.cg.ars.dto.UserDTO;
import com.cg.ars.exception.AirlineException;

public class AirlineServiceImpl implements IAirlineService{
  
	private AirlineReservationDAOImpl adao;

	public AirlineServiceImpl() {
		
		adao = new AirlineReservationDAOImpl();	
	}
	
	@Override
	public boolean isValidAuthority(UserDTO user) throws AirlineException {
		// TODO Auto-generated method stub
		return adao.isValidAuthority(user);
	}

	@Override
	public boolean isValidUser(UserDTO user) throws AirlineException {
		// TODO Auto-generated method stub
		return adao.isValidUser(user);
	}

	@Override
	public boolean isAvailableUsername(CustomerDTO customer)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.isAvailableUsername(customer);
	}

	@Override
	public boolean addNewPassenger(CustomerDTO customer, UserDTO user)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.addNewPassenger(customer, user);
	}

	@Override
	public List<String> findDepartureCities() throws AirlineException {
		// TODO Auto-generated method stub
		return adao.findDepartureCities();
	}

	@Override
	public List<String> findArrivalCities() throws AirlineException {
		// TODO Auto-generated method stub
		return adao.findArrivalCities();
	}

	@Override
	public List<FlightInfoDTO> searchFlightDetails(String deptCity,
			String arrCity, String deptDate) throws AirlineException {
		// TODO Auto-generated method stub
		return adao.searchFlightDetails(deptCity, arrCity, deptDate);
	}

	@Override
	public boolean isSeatAvailable(String flightNo, String seatType, int seatNum)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.isSeatAvailable(flightNo, seatType, seatNum);
	}

	@Override
	public String getCustomerMail(String username) throws AirlineException {
		// TODO Auto-generated method stub
		return adao.getCustomerMail(username);
	}

	@Override
	public String getCustomerName(String username) throws AirlineException {
		// TODO Auto-generated method stub
		return adao.getCustomerName(username);
	}

	@Override
	public float getTotalFare(String flightNo, String seatType, int seatNum)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.getTotalFare(flightNo, seatType, seatNum);
	}

	@Override
	public BookingInfoDTO bookFlight(BookingInfoDTO book)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.bookFlight(book);
	}

	@Override
	public boolean updateSeatNum(BookingInfoDTO book) throws AirlineException {
		// TODO Auto-generated method stub
		return adao.updateSeatNum(book);
	}

	@Override
	public List<BookingInfoDTO> getCustomerBookingInfo(String username)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.getCustomerBookingInfo(username);
	}

	@Override
	public boolean isValidBookingId(String bookingId, String username)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.isValidBookingId(bookingId, username);
	}

	@Override
	public boolean deleteCustomerBooking(String bookingId)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.deleteCustomerBooking(bookingId);
	}

	@Override
	public List<String> flightNoListDate(String deptDate, String arrDate)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.flightNoListDate(deptDate, arrDate);
	}

	@Override
	public List<BookingInfoDTO> viewFlightOccupancy(List<String> flightNoList)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.viewFlightOccupancy(flightNoList);
	}

	@Override
	public List<String> flightNoListCity(String srcCity, String destCity)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.flightNoListCity(srcCity, destCity);
	}

	@Override
	public boolean insertFlightDetails(FlightInfoDTO flight)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.insertFlightDetails(flight);
	}

	@Override
	public boolean isAvailableFlightNo(String flightNo) throws AirlineException {
		// TODO Auto-generated method stub
		return adao.isAvailableFlightNo(flightNo);
	}

	@Override
	public boolean deleteFlightDetails(String flightNo) throws AirlineException {
		// TODO Auto-generated method stub
		return adao.deleteFlightDetails(flightNo);
	}

	@Override
	public List<FlightInfoDTO> viewAllFlightSchedules() throws AirlineException {
		// TODO Auto-generated method stub
		return adao.viewAllFlightSchedules();
	}

	@Override
	public FlightInfoDTO viewFlightSchedule(String flightNo)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.viewFlightSchedule(flightNo);
	}

	@Override
	public List<CustomerDTO> getPassengerList(String flightNo)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.getPassengerList(flightNo);
	}

	@Override
	public List<BookingInfoDTO> getBookingList(String flightNo)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.getBookingList(flightNo);
	}

	@Override
	public List<FlightInfoDTO> viewFlightScheduleDestCity(String destCity)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.viewFlightScheduleDestCity(destCity);
	}

	@Override
	public List<FlightInfoDTO> viewFlightScheduleSrcCity(String srcCity)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.viewFlightScheduleSrcCity(srcCity);
	}

	@Override
	public List<FlightInfoDTO> viewFlightScheduleDeptDate(String deptDate)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.viewFlightScheduleDeptDate(deptDate);
	}

	@Override
	public List<FlightInfoDTO> viewFlightScheduleArrDate(String arrDate)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.viewFlightScheduleArrDate(arrDate);
	}

	@Override
	public List<String> getFlightNoList() throws AirlineException {
		// TODO Auto-generated method stub
		return adao.getFlightNoList();
	}

	@Override
	public boolean updateFlightDetails(FlightInfoDTO flight)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.updateFlightDetails(flight);
	}

	@Override
	public boolean updateFlightSeats(String bookingId) throws AirlineException {
		// TODO Auto-generated method stub
		return adao.updateFlightSeats(bookingId);
	}

	@Override
	public List<AirportDTO> viewAirports(String abbrevation)
			throws AirlineException {
		// TODO Auto-generated method stub
		return adao.viewAirports(abbrevation);
	}

}
