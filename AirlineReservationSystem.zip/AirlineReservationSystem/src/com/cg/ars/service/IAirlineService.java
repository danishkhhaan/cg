package com.cg.ars.service;

import java.util.List;

import com.cg.ars.dto.AirportDTO;
import com.cg.ars.dto.BookingInfoDTO;
import com.cg.ars.dto.CustomerDTO;
import com.cg.ars.dto.FlightInfoDTO;
import com.cg.ars.dto.UserDTO;
import com.cg.ars.exception.AirlineException;

public interface IAirlineService {

	public boolean isValidAuthority(UserDTO user) throws AirlineException;
	public boolean isValidUser(UserDTO user) throws AirlineException;
	public boolean isAvailableUsername(CustomerDTO customer) throws AirlineException;
	public boolean addNewPassenger(CustomerDTO customer, UserDTO user) throws AirlineException;
	public List<String> findDepartureCities() throws AirlineException;
	public List<String> findArrivalCities() throws AirlineException;
	public List<FlightInfoDTO> searchFlightDetails(String deptCity, String arrCity, String deptDate) throws AirlineException;
	public boolean isSeatAvailable(String flightNo, String seatType, int seatNum) throws AirlineException;
	public String getCustomerMail(String username) throws AirlineException;
	public String getCustomerName(String username) throws AirlineException;
	public float getTotalFare(String flightNo, String seatType, int seatNum) throws AirlineException;
	public BookingInfoDTO bookFlight(BookingInfoDTO book) throws AirlineException;
	public boolean updateSeatNum(BookingInfoDTO book) throws AirlineException;
	public List<BookingInfoDTO> getCustomerBookingInfo(String username) throws AirlineException;
	public boolean isValidBookingId(String bookingId, String username) throws AirlineException;
	public boolean deleteCustomerBooking(String bookingId) throws AirlineException;
	public List<String> flightNoListDate(String deptDate, String arrDate) throws AirlineException;
	public List<BookingInfoDTO> viewFlightOccupancy(List<String> flightNoList) throws AirlineException;
	public List<String> flightNoListCity(String srcCity, String destCity) throws AirlineException;
	public boolean insertFlightDetails(FlightInfoDTO flight) throws AirlineException;
	public boolean isAvailableFlightNo(String flightNo) throws AirlineException;
	public boolean deleteFlightDetails(String flightNo) throws AirlineException;
	public List<FlightInfoDTO> viewAllFlightSchedules() throws AirlineException;
	public FlightInfoDTO viewFlightSchedule(String flightNo) throws AirlineException;
	public List<CustomerDTO> getPassengerList(String flightNo) throws AirlineException;
	public List<BookingInfoDTO> getBookingList(String flightNo) throws AirlineException;
	public List<FlightInfoDTO> viewFlightScheduleDestCity(String destCity) throws AirlineException;
	public List<FlightInfoDTO> viewFlightScheduleSrcCity(String srcCity) throws AirlineException;
	public List<FlightInfoDTO> viewFlightScheduleDeptDate(String deptDate) throws AirlineException;
	public List<FlightInfoDTO> viewFlightScheduleArrDate(String arrDate) throws AirlineException;
	public List<String> getFlightNoList() throws AirlineException;
	public boolean updateFlightDetails(FlightInfoDTO flight) throws AirlineException;
	public boolean updateFlightSeats(String bookingId) throws AirlineException;
	public List<AirportDTO> viewAirports(String abbrevation) throws AirlineException;
}
