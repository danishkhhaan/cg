package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.cg.ars.dto.AirportDTO;
import com.cg.ars.dto.BookingInfoDTO;
import com.cg.ars.dto.CustomerDTO;
import com.cg.ars.dto.FlightInfoDTO;
import com.cg.ars.dto.UserDTO;
import com.cg.ars.exception.AirlineException;
import com.cg.ars.util.DBUtil;
import com.cg.ars.util.SQLDate;

public class AirlineReservationDAOImpl implements IAirlineReservationDAO {
	Connection conn;
	PreparedStatement pstmt;
	ResultSet rset;
	
	@Override
	public boolean isValidAuthority(UserDTO user) throws AirlineException {
		// TODO Auto-generated method stub
		
		conn = DBUtil.getConnection();
		String password, role;
		boolean validAuthority = false;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.USER_PASSWORD_ROLE);
			pstmt.setString(1, user.getUserName());
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				password = rset.getString(1);
				role = rset.getString(2);
				if((password.equals(user.getPassword())) && (role.equals(user.getRole())))
					validAuthority = true;
				
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return validAuthority;
	}

	@Override
	public boolean isValidUser(UserDTO user) throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		String password;
		boolean validUser = false;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.USER_PASSWORD);
			pstmt.setString(1, user.getUserName());
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				password = rset.getString(1);
				if(password.equals(user.getPassword()))
					validUser = true;
				
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return validUser;
	}

	@Override
	public boolean isAvailableUsername(CustomerDTO customer)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		String username = customer.getUserName();
		boolean validUsername = true;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.USERNAME_LIST);
			rset = pstmt.executeQuery();
			
			while(rset.next())
			{
				if(username.equals(rset.getString(1)))
					validUsername = false;
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return validUsername;
	}

	@Override
	public boolean addNewPassenger(CustomerDTO customer, UserDTO user)
			throws AirlineException {
		// TODO Auto-generated method stub
        conn = DBUtil.getConnection();
		
		int record = 0;
		boolean recordInserted = false;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.REGISTER_CUSTOMER);
			pstmt.setString(1, customer.getFirstName());
			pstmt.setString(2, customer.getLastName());
			pstmt.setString(3, customer.getUserName());
			pstmt.setString(4, customer.getEmail());
			pstmt.setLong(5, customer.getPhoneNo());
			pstmt.executeUpdate();
			
			pstmt = conn.prepareStatement(IQueryMapper.ADD_NEW_USER);
			
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, Long.toString(user.getMobileNo()));
			record = pstmt.executeUpdate();
			
			if(record > 0)
				recordInserted = true;
			
			conn.commit();
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return recordInserted;
	}

	@Override
	public List<String> findDepartureCities() throws AirlineException {
		// TODO Auto-generated method stub
conn = DBUtil.getConnection();
		
		List<String> deptCityList = new ArrayList<String>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.DEPARTURE_CITY_LIST);
			rset = pstmt.executeQuery();
			
			while(rset.next())
			{
				deptCityList.add(rset.getString(1));
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return deptCityList;
	}

	@Override
	public List<String> findArrivalCities() throws AirlineException {
		// TODO Auto-generated method stub
conn = DBUtil.getConnection();
		
		List<String> arrCityList = new ArrayList<String>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.ARRIVAL_CITY_LIST);
			rset = pstmt.executeQuery();
			
			while(rset.next())
			{
				arrCityList.add(rset.getString(1));
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return arrCityList;
	}

	@Override
	public List<FlightInfoDTO> searchFlightDetails(String deptCity,
			String arrCity, String deptDate) throws AirlineException {
		// TODO Auto-generated method stub
conn = DBUtil.getConnection();
		
		List<FlightInfoDTO> flightList = new ArrayList<FlightInfoDTO>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.SEARCH_FLIGHT_DETAILS);
			pstmt.setString(1, deptCity);
			pstmt.setString(2, arrCity);
			pstmt.setDate(3, SQLDate.convertDate(deptDate));
			rset = pstmt.executeQuery();
			
			FlightInfoDTO flight;
			
			while(rset.next())
			{
				flight = new FlightInfoDTO();
				flight.setFlightNo(rset.getString(1));
				flight.setAirLine(rset.getString(2));
				flight.setDeptCity(deptCity);
				flight.setArrCity(arrCity);
				flight.setDeptDate(rset.getString(5));
				flight.setArrDate(rset.getString(6));
				flight.setDeptTime(rset.getString(7));
				flight.setArrTime(rset.getString(8));
				flight.setFirstSeats(rset.getInt(9));
				flight.setFirstSeatFare(rset.getFloat(10));
				flight.setBussiSeats(rset.getInt(11));
				flight.setBussiSeatFare(rset.getFloat(12));
				
				flightList.add(flight);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return flightList;
	}

	@Override
	public boolean isSeatAvailable(String flightNo, String seatType, int seatNum)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		boolean seatAvailable = false;
		int availableSeats = 0;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
		
			pstmt = conn.prepareStatement(IQueryMapper.SEAT_NUMBERS);
			pstmt.setString(1, flightNo);
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				if(seatType.equals("First Class"))
					availableSeats = rset.getInt(1);
				else
					availableSeats = rset.getInt(2);
			}
			if(availableSeats >= seatNum)
				seatAvailable = true;

		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return seatAvailable;
	}

	@Override
	public String getCustomerMail(String username) throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		String emailId = null;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
				pstmt = conn.prepareStatement(IQueryMapper.CUSTOMER_MAIL);
				pstmt.setString(1, username);
				rset = pstmt.executeQuery();
				
				if(rset.next())
					emailId = rset.getString(1);
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return emailId;
	}

	@Override
	public String getCustomerName(String username) throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		String custName = null;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
				pstmt = conn.prepareStatement(IQueryMapper.CUSTOMER_NAME);
				pstmt.setString(1, username);
				rset = pstmt.executeQuery();
				
				if(rset.next())
				{
					String firstName = rset.getString(1);
					String lastName = rset.getString(2);
					custName = firstName +" "+ lastName;
				}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return custName;
	}

	@Override
	public float getTotalFare(String flightNo, String seatType, int seatNum)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		float totalFare = 0.0F;
		float farePerSeat = 0.0F;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			if(seatType.equals("First Class"))
				pstmt = conn.prepareStatement(IQueryMapper.FIRST_CLASS_FARE);
			else
				pstmt = conn.prepareStatement(IQueryMapper.BUSINESS_CLASS_FARE);
			
			pstmt.setString(1, flightNo);
			rset = pstmt.executeQuery();
			
			if(rset.next())
				farePerSeat = rset.getFloat(1);
			
			totalFare = farePerSeat * seatNum;
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return totalFare;
	}

	@Override
	public BookingInfoDTO bookFlight(BookingInfoDTO book)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		String bookingId = null;
		int seatno=0;
		BookingInfoDTO bb= new BookingInfoDTO();
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.BOOK_FLIGHT);
	
			pstmt.setString(1, book.getCustMail());
			pstmt.setInt(2, book.getNoOfPassengers());
			pstmt.setString(3, book.getClassType());
			pstmt.setFloat(4, book.getTotalFare());
			pstmt.setString(5, book.getCreditCardInfo());
			pstmt.setString(6, book.getSrcCity());
			pstmt.setString(7, book.getDestCity());
			pstmt.setString(9, book.getFlightNo());
			
			pstmt.setString(8, book.getCustName());
	
			int record = pstmt.executeUpdate();
			
			conn.commit();	
			
			if(record >= 1)
			{
				pstmt = conn.prepareStatement(IQueryMapper.BOOKING_ID);
				rset = pstmt.executeQuery();
				
				if(rset.next())
				{
					bookingId = rset.getString(1);
				}
				
			}			
			if(record == 1)
			{
				pstmt = conn.prepareStatement(IQueryMapper.SEAT_NO);
				rset = pstmt.executeQuery();
				
				if(rset.next())
				{
					seatno = rset.getInt(1);
				}
				
			}
			bb.setBookingId(bookingId);
			bb.setSeatNo(seatno);
			
		}
		catch(SQLException e)
		{
			throw new AirlineException(e.getMessage());
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return bb;
	}

	@Override
	public boolean updateSeatNum(BookingInfoDTO book) throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		boolean updatedRecord = true;
		int availableSeats = 0, newAvailableSeats = 0;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
					
			pstmt = conn.prepareStatement(IQueryMapper.SEAT_NUMBERS);
			pstmt.setString(1, book.getFlightNo());
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				if(book.getClassType().equals("First Class"))
				{
					availableSeats = rset.getInt(1);
					pstmt = conn.prepareStatement(IQueryMapper.FIRST_CLASS_SEATS_REMAINING);
				}
				else
				{
					availableSeats = rset.getInt(2);
					pstmt = conn.prepareStatement(IQueryMapper.BUSINESS_CLASS_SEATS_REMAINING);
				}
			}
			newAvailableSeats = availableSeats - book.getNoOfPassengers();
			pstmt.setInt(1, newAvailableSeats);
			pstmt.setString(2, book.getFlightNo());
			int record = pstmt.executeUpdate();
			
			if(record >= 1)
				updatedRecord = true;
			
			conn.commit();				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return updatedRecord;
	}

	@Override
	public List<BookingInfoDTO> getCustomerBookingInfo(String username)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		List<BookingInfoDTO> bookingInfoList = new ArrayList<BookingInfoDTO>();
		String custName = null;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.CUSTOMER_NAME);
			pstmt.setString(1, username);
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				String firstName = rset.getString(1);
				String lastName = rset.getString(2);
				custName = firstName +" "+ lastName;
			}		
		
			pstmt = conn.prepareStatement(IQueryMapper.CUSTOMER_BOOKING_INFO);
			pstmt.setString(1, custName);
			rset = pstmt.executeQuery();
		   
			BookingInfoDTO bookingObj;
			
			while(rset.next())
			{
				bookingObj = new BookingInfoDTO();
				bookingObj.setBookingId(rset.getString(1));
				bookingObj.setCustName(rset.getString(2));
				bookingObj.setNoOfPassengers(rset.getInt(3));
				bookingObj.setClassType(rset.getString(4));
				bookingObj.setTotalFare(rset.getFloat(5));
				bookingObj.setSrcCity(rset.getString(6));
				bookingObj.setDestCity(rset.getString(7));
				bookingObj.setFlightNo(rset.getString(8));
				
				bookingInfoList.add(bookingObj);
			}
		}
		catch(SQLException e)
		{
			throw new AirlineException(e.getMessage());
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return bookingInfoList;
	}

	@Override
	public boolean isValidBookingId(String bookingId, String username)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		boolean validBookingId = false;
		String custName = null;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.CUSTOMER_NAME);
			pstmt.setString(1, username);
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				String firstName = rset.getString(1);
				String lastName = rset.getString(2);
				custName = firstName +" "+ lastName;
			}		
			
			pstmt = conn.prepareStatement(IQueryMapper.BOOKING_CUSTOMER_NAME);
			
			pstmt.setString(1, bookingId);
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				if(rset.getString(1).equals(custName))
					validBookingId = true;
			}
		}
		catch(SQLException e)
		{
			throw new AirlineException(e.getMessage());
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return validBookingId;
	}

	@Override
	public boolean deleteCustomerBooking(String bookingId)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		boolean recordDeleted = false;
		int record = 0;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.CUTOMER_DELETE_BOOKING);
			
			pstmt.setString(1, bookingId);
			record = pstmt.executeUpdate();
			
			if(record >= 1)
			{
				recordDeleted = true;
			}
			
			conn.commit();
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return recordDeleted;
	}

	@Override
	public List<String> flightNoListDate(String deptDate, String arrDate)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		List<String> flightNoList = new ArrayList<String>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.FLIGHT_NO_LIST_DATE);
			pstmt.setDate(1, SQLDate.convertDate(deptDate));
			pstmt.setDate(2, SQLDate.convertDate(arrDate));
			rset = pstmt.executeQuery();
			
			while(rset.next())
			{
				flightNoList.add(rset.getString(1));
			}
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return flightNoList;
	}

	@Override
	public List<BookingInfoDTO> viewFlightOccupancy(List<String> flightNoList)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		List<BookingInfoDTO> occupancyList = new ArrayList<BookingInfoDTO>();
				
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			BookingInfoDTO bookObj = null;
			
			for(String flightNo : flightNoList)
			{
				int occupancy = 0;
				
				pstmt = conn.prepareStatement(IQueryMapper.OCCUPANCY_COUNT);
				pstmt.setString(1, flightNo);
				rset = pstmt.executeQuery();
				
				while(rset.next())
				{
					occupancy += rset.getInt(1); 
				}
				
				bookObj = new BookingInfoDTO();
				bookObj.setFlightNo(flightNo);
				bookObj.setNoOfPassengers(occupancy);
				
				occupancyList.add(bookObj);
			}
			
		}
		catch(SQLException e)
		{
			throw new AirlineException(e.getMessage());
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return occupancyList;
	}

	@Override
	public List<String> flightNoListCity(String srcCity, String destCity)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		List<String> flightNoList = new ArrayList<String>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.FLIGHT_NO_LIST_CITY);
			pstmt.setString(1, srcCity);
			pstmt.setString(2, destCity);
			rset = pstmt.executeQuery();
			
			while(rset.next())
			{
				flightNoList.add(rset.getString(1));
			}
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return flightNoList;
	}

	@Override
	public boolean insertFlightDetails(FlightInfoDTO flight)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		boolean recordInserted = false;
		int record;
				
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.ADD_NEW_FLIGHT);
			
			pstmt.setString(1, flight.getFlightNo());
			pstmt.setString(2, flight.getAirLine());
			pstmt.setString(3, flight.getDeptCity());
			pstmt.setString(4, flight.getArrCity());
			pstmt.setDate(5, SQLDate.convertDate(flight.getDeptDate()));
			pstmt.setDate(6, SQLDate.convertDate(flight.getArrDate()));
			pstmt.setTimestamp(7, Timestamp.valueOf(flight.getDeptTime()));
			pstmt.setTimestamp(8, Timestamp.valueOf(flight.getArrTime()));
			pstmt.setInt(9, flight.getFirstSeats());
			pstmt.setFloat(10, flight.getFirstSeatFare());
			pstmt.setInt(11, flight.getBussiSeats());
			pstmt.setFloat(12, flight.getBussiSeatFare());
			
			record = pstmt.executeUpdate();
			
			if(record == 1)
				recordInserted = true;
			
			conn.commit();
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again." +e.getMessage());
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return recordInserted;
	}

	@Override
	public boolean isAvailableFlightNo(String flightNo) throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		boolean availableFlightNo = false;
						
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.FLIGHT_NO_LIST);
			rset = pstmt.executeQuery();
			
			while(rset.next())
			{
				if(flightNo.equals(rset.getString(1)))
					availableFlightNo = true;
			}
			
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return availableFlightNo;
	}

	@Override
	public boolean deleteFlightDetails(String flightNo) throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		boolean recordDeleted = false;
		int record;
				
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.DELETE_FLIGHT);
			pstmt.setString(1, flightNo);
			record = pstmt.executeUpdate();
			
			if(record >= 1)
				recordDeleted = true;
			
			conn.commit();
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again." +e.getMessage());
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return recordDeleted;
	}

	@Override
	public List<FlightInfoDTO> viewAllFlightSchedules() throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		List<FlightInfoDTO> flightList = new ArrayList<FlightInfoDTO>();
		
		try
		{	
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.ALL_FLIGHTS);
			rset = pstmt.executeQuery();
			
			FlightInfoDTO flight;
			
			while(rset.next())
			{
				flight = new FlightInfoDTO();
				
				flight.setFlightNo(rset.getString(1));
				flight.setAirLine(rset.getString(2));
				flight.setDeptCity(rset.getString(3));
				flight.setArrCity(rset.getString(4));
				flight.setDeptDate(rset.getString(5));
				flight.setArrDate(rset.getString(6));
				flight.setDeptTime(rset.getString(7).substring(11));
				flight.setArrTime(rset.getString(8).substring(11));
				flight.setFirstSeats(rset.getInt(9));
				flight.setFirstSeatFare(rset.getFloat(10));
				flight.setBussiSeats(rset.getInt(11));
				flight.setBussiSeatFare(rset.getFloat(12));
				
				flightList.add(flight);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return flightList;
	}

	@Override
	public FlightInfoDTO viewFlightSchedule(String flightNo)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		FlightInfoDTO flight = new FlightInfoDTO();
		
		try
		{	
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.VIEW_FLIGHTID_SCHEDULE);
			pstmt.setString(1, flightNo);
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				flight.setFlightNo(rset.getString(1));
				flight.setAirLine(rset.getString(2));
				flight.setDeptCity(rset.getString(3));
				flight.setArrCity(rset.getString(4));
				flight.setDeptDate(rset.getString(5));
				flight.setArrDate(rset.getString(6));
				flight.setDeptTime(rset.getString(7).substring(11));
				flight.setArrTime(rset.getString(8).substring(11));
				flight.setFirstSeats(rset.getInt(9));
				flight.setFirstSeatFare(rset.getFloat(10));
				flight.setBussiSeats(rset.getInt(11));
				flight.setBussiSeatFare(rset.getFloat(12));	
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return flight;
	}

	@Override
	public List<CustomerDTO> getPassengerList(String flightNo)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		List<CustomerDTO> passengerList = new ArrayList<CustomerDTO>();
		
		try
		{	
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.PASSENGER_LIST);
			pstmt.setString(1, flightNo);
			rset = pstmt.executeQuery();
			
			CustomerDTO custDto;
			
			while(rset.next())
			{
				custDto = new CustomerDTO();
				
				custDto.setFirstName(rset.getString(1));
				custDto.setLastName(rset.getString(2));
				custDto.setEmail(rset.getString(3));
				custDto.setPhoneNo(rset.getLong(4));
				
				passengerList.add(custDto);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again."+e.getMessage());
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return passengerList;
	}

	@Override
	public List<BookingInfoDTO> getBookingList(String flightNo)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		List<BookingInfoDTO> bookingList = new ArrayList<BookingInfoDTO>();
		
		try
		{	
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.BOOKING_LIST);
			pstmt.setString(1, flightNo);
			rset = pstmt.executeQuery();
			
			BookingInfoDTO book;
			
			while(rset.next())
			{
				book = new BookingInfoDTO();
				
				book.setBookingId(rset.getString(1));
				book.setCustName(rset.getString(2));
				book.setNoOfPassengers(rset.getInt(3));
				book.setClassType(rset.getString(4));
				
				bookingList.add(book);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return bookingList;
	}

	@Override
	public List<FlightInfoDTO> viewFlightScheduleDestCity(String destCity)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		List<FlightInfoDTO> flightList = new ArrayList<FlightInfoDTO>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.FLIGHT_DETAILS_DEST_CITY);
			pstmt.setString(1, destCity);
			rset = pstmt.executeQuery();
			
			FlightInfoDTO flight;
			
			while(rset.next())
			{
				flight = new FlightInfoDTO();
				flight.setFlightNo(rset.getString(1));
				flight.setAirLine(rset.getString(2));
				flight.setDeptCity(rset.getString(3));
				flight.setArrCity(destCity);
				flight.setDeptDate(rset.getString(5));
				flight.setArrDate(rset.getString(6));
				flight.setDeptTime(rset.getString(7));
				flight.setArrTime(rset.getString(8));
				flight.setFirstSeats(rset.getInt(9));
				flight.setFirstSeatFare(rset.getFloat(10));
				flight.setBussiSeats(rset.getInt(11));
				flight.setBussiSeatFare(rset.getFloat(12));
				
				flightList.add(flight);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return flightList;
	}

	@Override
	public List<FlightInfoDTO> viewFlightScheduleSrcCity(String srcCity)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		List<FlightInfoDTO> flightList = new ArrayList<FlightInfoDTO>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.FLIGHT_DETAILS_SRC_CITY);
			pstmt.setString(1, srcCity);
			rset = pstmt.executeQuery();
			
			FlightInfoDTO flight;
			
			while(rset.next())
			{
				flight = new FlightInfoDTO();
				flight.setFlightNo(rset.getString(1));
				flight.setAirLine(rset.getString(2));
				flight.setDeptCity(srcCity);
				flight.setArrCity(rset.getString(4));
				flight.setDeptDate(rset.getString(5));
				flight.setArrDate(rset.getString(6));
				flight.setDeptTime(rset.getString(7).substring(11));
				flight.setArrTime(rset.getString(8).substring(11));
				flight.setFirstSeats(rset.getInt(9));
				flight.setFirstSeatFare(rset.getFloat(10));
				flight.setBussiSeats(rset.getInt(11));
				flight.setBussiSeatFare(rset.getFloat(12));
				
				flightList.add(flight);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return flightList;
	}

	@Override
	public List<FlightInfoDTO> viewFlightScheduleDeptDate(String deptDate)
			throws AirlineException {
		// TODO Auto-generated method stub

		conn = DBUtil.getConnection();
		List<FlightInfoDTO> flightList = new ArrayList<FlightInfoDTO>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.FLIGHT_DETAILS_DEPT_DATE);
			pstmt.setDate(1, SQLDate.convertDate(deptDate));
			rset = pstmt.executeQuery();
			
			FlightInfoDTO flight;
			
			while(rset.next())
			{
				flight = new FlightInfoDTO();
				flight.setFlightNo(rset.getString(1));
				flight.setAirLine(rset.getString(2));
				flight.setDeptCity(rset.getString(3));
				flight.setArrCity(rset.getString(4));
				flight.setDeptDate(rset.getString(5));
				flight.setArrDate(rset.getString(6));
				flight.setDeptTime(rset.getString(7).substring(11));
				flight.setArrTime(rset.getString(8).substring(11));
				flight.setFirstSeats(rset.getInt(9));
				flight.setFirstSeatFare(rset.getFloat(10));
				flight.setBussiSeats(rset.getInt(11));
				flight.setBussiSeatFare(rset.getFloat(12));
				
				flightList.add(flight);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return flightList;
	}

	@Override
	public List<FlightInfoDTO> viewFlightScheduleArrDate(String arrDate)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		List<FlightInfoDTO> flightList = new ArrayList<FlightInfoDTO>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.FLIGHT_DETAILS_ARR_DATE);
			pstmt.setDate(1,SQLDate.convertDate(arrDate));
			rset = pstmt.executeQuery();
			
			FlightInfoDTO flight;
			
			while(rset.next())
			{
				flight = new FlightInfoDTO();
				flight.setFlightNo(rset.getString(1));
				flight.setAirLine(rset.getString(2));
				flight.setDeptCity(rset.getString(3));
				flight.setArrCity(rset.getString(4));
				flight.setDeptDate(rset.getString(5));
				flight.setArrDate(rset.getString(6));
				flight.setDeptTime(rset.getString(7).substring(11));
				flight.setArrTime(rset.getString(8).substring(11));
				flight.setFirstSeats(rset.getInt(9));
				flight.setFirstSeatFare(rset.getFloat(10));
				flight.setBussiSeats(rset.getInt(11));
				flight.setBussiSeatFare(rset.getFloat(12));
				
				flightList.add(flight);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return flightList;
	}

	@Override
	public List<String> getFlightNoList() throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		List<String> flightNoList = new ArrayList<String>();
		
		try
		{	
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.FLIGHT_NO_LIST);
			rset = pstmt.executeQuery();
			
			while(rset.next())
			{
				flightNoList.add(rset.getString(1));
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return flightNoList;
	}

	@Override
	public boolean updateFlightDetails(FlightInfoDTO flight)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		boolean recordUpdated = false;
		int record;
				
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.UPDATE_FLIGHT);
			
			pstmt.setString(1, flight.getAirLine());
			pstmt.setString(2, flight.getDeptCity());
			pstmt.setString(3, flight.getArrCity());
			pstmt.setDate(4, SQLDate.convertDate(flight.getDeptDate()));
			pstmt.setDate(5, SQLDate.convertDate(flight.getArrDate()));
			pstmt.setTimestamp(6, Timestamp.valueOf(flight.getDeptTime()));
			pstmt.setTimestamp(7, Timestamp.valueOf(flight.getArrTime()));
			pstmt.setInt(8, flight.getFirstSeats());
			pstmt.setFloat(9, flight.getFirstSeatFare());
			pstmt.setInt(10, flight.getBussiSeats());
			pstmt.setFloat(11, flight.getBussiSeatFare());
			pstmt.setString(12, flight.getFlightNo());
			
			record = pstmt.executeUpdate();
			
			if(record >= 1)
				recordUpdated = true;
			   
			conn.commit();
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again." +e.getMessage());
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return recordUpdated;
	}

	@Override
	public boolean updateFlightSeats(String bookingId) throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		boolean updatedRecord = false;
		int record = 0, numPassengers = 0, totalPassengers = 0;
		String classType = null, flightNo = null;
				
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.BOOKING_UPDATE_REQ);
		
			pstmt.setString(1, bookingId);
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				numPassengers = rset.getInt(1);
				classType = rset.getString(2);
				flightNo = rset.getString(3);				
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.SEAT_NUMBERS);
			pstmt.setString(1, flightNo);
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				if(classType.equals("First Class"))
				{
					totalPassengers = rset.getInt(1);
					pstmt = conn.prepareStatement(IQueryMapper.FIRST_CLASS_SEATS_REMAINING);
					
					
				}
				else
				{
					totalPassengers = rset.getInt(2);
					pstmt = conn.prepareStatement(IQueryMapper.BUSINESS_CLASS_SEATS_REMAINING);
					
				}
			}
			
			totalPassengers += numPassengers;
			pstmt.setInt(1, totalPassengers);
			pstmt.setString(2, flightNo);
			record = pstmt.executeUpdate();
			
			
			if(record >= 1)
				updatedRecord = true;
					
			conn.commit();
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again." +e.getMessage());
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return updatedRecord;
	}

	@Override
	public List<AirportDTO> viewAirports(String abbrevation)
			throws AirlineException {
		// TODO Auto-generated method stub
		conn = DBUtil.getConnection();
		
        List<AirportDTO> airportList = new ArrayList<AirportDTO>();
		AirportDTO aDto;
		try
		{	
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.AIRPORT_LIST);
			pstmt.setString(1,abbrevation);
			rset = pstmt.executeQuery();
			
			while(rset.next())
			{
				
			    aDto= new AirportDTO();
				aDto.setAbbrevation(rset.getString(2));
				aDto.setAirportName(rset.getString(1));
				aDto.setLocation(rset.getString(3));
				airportList.add(aDto);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again."+e.getMessage());
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return airportList;
	}
	}

