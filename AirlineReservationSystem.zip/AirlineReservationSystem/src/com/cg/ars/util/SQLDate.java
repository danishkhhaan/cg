package com.cg.ars.util;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.cg.ars.exception.AirlineException;

public class SQLDate {

	public static java.sql.Date convertDate(String date) throws AirlineException
	{
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date javaDate;
		
		try 
		{
			javaDate = formatter.parse(date);
		} 
		catch (ParseException e) 
		{
			throw new AirlineException(e.getMessage());
		}
		
		java.sql.Date sqlDate = new Date(javaDate.getTime());
		
		return sqlDate;
  }
}
