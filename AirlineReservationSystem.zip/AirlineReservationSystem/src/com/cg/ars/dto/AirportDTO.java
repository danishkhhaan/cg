package com.cg.ars.dto;

public class AirportDTO 
{
	private String airportName;
	private String abbrevation;
	private String location;
	
	public AirportDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getAirportName() {
		return airportName;
	}
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}
	public String getAbbrevation() {
		return abbrevation;
	}
	public void setAbbrevation(String abbrevation) {
		this.abbrevation = abbrevation;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
}
