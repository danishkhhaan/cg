package com.cg.ars.dto;

public class FlightInfoDTO 
{
	private String flightNo;
	private String airLine;
	private String deptCity;
	private String arrCity;
	private String deptDate;
	private String arrDate;
	private String	arrTime;
	private String deptTime;
	private int firstSeats;
	private float firstSeatFare;
	private int bussiSeats;
	private float bussiSeatFare;
	
	public FlightInfoDTO() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public String getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}
	public String getAirLine() {
		return airLine;
	}
	public void setAirLine(String airLine) {
		this.airLine = airLine;
	}
	public String getDeptCity() {
		return deptCity;
	}
	public void setDeptCity(String deptCity) {
		this.deptCity = deptCity;
	}
	public String getArrCity() {
		return arrCity;
	}
	public void setArrCity(String arrCity) {
		this.arrCity = arrCity;
	}
	public String getDeptDate() {
		return deptDate;
	}
	public void setDeptDate(String deptDate) {
		this.deptDate = deptDate;
	}
	public String getArrDate() {
		return arrDate;
	}
	public void setArrDate(String arrDate) {
		this.arrDate = arrDate;
	}
	public String getArrTime() {
		return arrTime;
	}
	public void setArrTime(String arrTime) {
		this.arrTime = arrTime;
	}
	public String getDeptTime() {
		return deptTime;
	}
	public void setDeptTime(String deptTime) {
		this.deptTime = deptTime;
	}
	public int getFirstSeats() {
		return firstSeats;
	}
	public void setFirstSeats(int firstSeats) {
		this.firstSeats = firstSeats;
	}
	public float getFirstSeatFare() {
		return firstSeatFare;
	}
	public void setFirstSeatFare(float firstSeatFare) {
		this.firstSeatFare = firstSeatFare;
	}
	public int getBussiSeats() {
		return bussiSeats;
	}
	public void setBussiSeats(int bussiSeats) {
		this.bussiSeats = bussiSeats;
	}
	public float getBussiSeatFare() {
		return bussiSeatFare;
	}
	public void setBussiSeatFare(float bussiSeatFare) {
		this.bussiSeatFare = bussiSeatFare;
	}
	
	
	
	
	
}
