package com.cg.webservice.publisher;

public class ProductPublisher {

}
