package com.cg.webservice.dao;

public class ProductDaoImpl {

	public float getProductPrice(String pname) {
		// TODO Auto-generated method stub
		return 0;
	}

}
