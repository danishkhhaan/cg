package com.cg.webservice.service;

import javax.jws.WebService;

import com.cg.webservice.dao.ProductDaoImpl;

@WebService(endpointInterface 
		= "com.cg.webservice.service.IProductService")
public class ProductServiceImpl {
	
	ProductDaoImpl dao;
	public float getProductPrice(String pname) {
		dao = new ProductDaoImpl();
		return dao.getProductPrice(pname);
	}

	
}
