package com.cg.webservice.client;

public class Client {

}
