package com.cg.mc.dto;

public class RegisterDTO {
	
	private int firm_id;
	private String owner_name;
	private String business_name;
	private String email;
	private String mobile_no;
	private char isactive;
	
	public int getFirm_id() {
		return firm_id;
	}
	public void setFirm_id(int firm_id) {
		this.firm_id = firm_id;
	}
	public String getOwner_name() {
		return owner_name;
	}
	public void setOwner_name(String owner_name) {
		this.owner_name = owner_name;
	}
	public String getBusiness_name() {
		return business_name;
	}
	public void setBusiness_name(String business_name) {
		this.business_name = business_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public char getIsactive() {
		return isactive;
	}
	public void setIsactive(char isactive) {
		this.isactive = isactive;
	}

}
