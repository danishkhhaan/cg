package com.cg.mc.dao;

public interface IQueryMapper {
	
	
	public static final String INSERT_QUERY = "INSERT INTO FIRMS_MASTER VALUES(?,?,?,?,?,?)";
	public static final String GETSEQUENCE_ID = "SELECT seq_firm_master.NEXTVAL FROM DUAL";
	public static final String UPDATESTATUS = "UPDATE FIRMS_MASTER SET isactive = 'Y' WHERE email = ? ";
	
	
}
