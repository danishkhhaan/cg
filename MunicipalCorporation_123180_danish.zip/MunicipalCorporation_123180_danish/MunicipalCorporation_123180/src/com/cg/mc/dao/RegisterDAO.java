package com.cg.mc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.mc.dto.RegisterDTO;
import com.cg.mc.exception.FirmException;
import com.cg.mc.util.DBConnection;

public class RegisterDAO implements IRegisterDAO {

	Connection connection = null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;

	@Override
	public int addRegistration(RegisterDTO dto) throws FirmException {

		int result = 0;
		int sequence = 0;

		try {

			connection = DBConnection.getConnection();

			preparedStatement = connection
					.prepareStatement(IQueryMapper.GETSEQUENCE_ID);

			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				sequence = resultSet.getInt(1);
			} else {
				sequence = 0;
			}

			if (sequence != 0) {

				preparedStatement = connection
						.prepareStatement(IQueryMapper.INSERT_QUERY);
				preparedStatement.setInt(1, sequence);
				preparedStatement.setString(2, dto.getOwner_name());
				preparedStatement.setString(3, dto.getBusiness_name());
				preparedStatement.setString(4, dto.getEmail());
				preparedStatement.setString(5, dto.getMobile_no());
				preparedStatement.setString(6, "N");

				result = preparedStatement.executeUpdate();

				if (result == 0) {
					return 0;
				}

			}

		} catch (SQLException e) {
			throw new FirmException(e.getMessage());
		} catch (Exception e) {
			throw new FirmException(e.getMessage());
		}/* finally {
			try {
				if (connection != null) {
					preparedStatement.close();
					connection.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new FirmException("connection not closed successfully");
			}
		}
*/
		return result;
	}

	@Override
	public int updateStatus(String email) throws FirmException {
		
		int result = 0;
		
		
		
		try {
			connection = DBConnection.getConnection();
			
			if (connection != null) {
				preparedStatement = connection.prepareStatement(IQueryMapper.UPDATESTATUS);
				preparedStatement.setString(1, email);
				
				result = preparedStatement.executeUpdate();
				
				if (result == 0) {
					return 0;
				}
				
			}
		}catch (SQLException e) {
			throw new FirmException(e.getMessage());
		}/* finally {
			try {
				if (connection != null) {
					preparedStatement.close();
					connection.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new FirmException("connection not closed successfully");
			}
		}
*/
		return result;		
	}

}
