package com.cg.mc.dao;

import com.cg.mc.dto.RegisterDTO;
import com.cg.mc.exception.FirmException;

public interface IRegisterDAO {
	
	public int addRegistration(RegisterDTO dto) throws FirmException;
	public int updateStatus(String email) throws FirmException;

}
