package com.cg.mc.exception;

public class FirmException extends Exception{

	public FirmException(String msg)
	{
		super(msg);
	}
}
