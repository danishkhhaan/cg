package com.cg.mc.service;

import com.cg.mc.dao.IRegisterDAO;
import com.cg.mc.dao.RegisterDAO;
import com.cg.mc.dto.RegisterDTO;
import com.cg.mc.exception.FirmException;

public class RegisterService implements IRegisterService {

	@Override
	public int addRegistration(RegisterDTO dto) throws FirmException {

		IRegisterDAO dao = new RegisterDAO();
		int firmId = dao.addRegistration(dto);
		return firmId;
	}

	@Override
	public int updateStatus(String email) throws FirmException {
	
		IRegisterDAO dao = new RegisterDAO();
		int updateResult = dao.updateStatus(email);
		return updateResult;
	}

}
