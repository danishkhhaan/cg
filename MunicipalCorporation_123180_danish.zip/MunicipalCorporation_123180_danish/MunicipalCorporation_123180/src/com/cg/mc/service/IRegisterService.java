package com.cg.mc.service;

import com.cg.mc.dto.RegisterDTO;
import com.cg.mc.exception.FirmException;

public interface IRegisterService {

	public int addRegistration(RegisterDTO dto) throws FirmException;
	public int updateStatus(String email) throws FirmException;
}
