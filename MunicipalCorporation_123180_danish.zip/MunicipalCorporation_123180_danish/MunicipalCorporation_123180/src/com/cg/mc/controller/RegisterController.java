package com.cg.mc.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.mc.dto.RegisterDTO;
import com.cg.mc.exception.FirmException;
import com.cg.mc.service.IRegisterService;
import com.cg.mc.service.RegisterService;

@WebServlet({ "/RegisterController", "/home", "/register", "/doRegister",
		"/activate", "/validateActivation" })
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private int result;
	private String email;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		String path = request.getServletPath();

		if (path.equals("/home")) {

			RequestDispatcher rd = request.getRequestDispatcher("/home.jsp");
			rd.forward(request, response);

		}

		if (path.equals("/register")) {

			RequestDispatcher rd = request
					.getRequestDispatcher("/register.jsp");
			rd.forward(request, response);

		}

		if (path.equals("/doRegister")) {

			RegisterDTO dto = new RegisterDTO();

			String tmpfName = request.getParameter("fName").trim();
			String tmpmName = request.getParameter("mName").trim();
			String tmplName = request.getParameter("lName").trim();
			String tmpName = tmpfName + tmpmName + tmplName;
			dto.setOwner_name(tmpName);

			String tmpbName = request.getParameter("bName").trim();
			dto.setBusiness_name(tmpbName);

			String tmpemail = request.getParameter("email1").trim();
			dto.setEmail(tmpemail);
			this.email = tmpemail;

			String tmpPhone = request.getParameter("phone");
			dto.setMobile_no(tmpPhone);

			HttpSession session = request.getSession();
			session.setAttribute("email", tmpemail);

			IRegisterService service = new RegisterService();
			try {

				int firmId = service.addRegistration(dto);
				if (firmId != 0) {
					Random random = new Random();
					int low = 10000;
					int high = 1000000;
					int res = random.nextInt(high - low) + low;
					this.result = res;
					request.setAttribute("result", result);
					RequestDispatcher rd = request
							.getRequestDispatcher("/success.jsp");
					rd.forward(request, response);
				}
			} catch (FirmException e) {
				out.println(e.getMessage());
			}

		}

		if (path.equals("/activate")) {

			RequestDispatcher rd = request
					.getRequestDispatcher("/activate.jsp");
			rd.forward(request, response);

		}

		if (path.equals("/validateActivation")) {

			String tmpemail = request.getParameter("email2").trim();
			String tmpcode2 = request.getParameter("code2").trim();
			int code = Integer.valueOf(tmpcode2);

			if (result == code && email.equals(tmpemail)) {

				
				IRegisterService service = new RegisterService();
				try {
					int updateResult = service.updateStatus(email);
					if (updateResult == 1) {

						
						RequestDispatcher rd = request
								.getRequestDispatcher("/activated.jsp");
						rd.forward(request, response);

	//			out.println("code and email is matched");
					} else {

						RequestDispatcher rd = request
								.getRequestDispatcher("/errorpage.jsp");
						rd.forward(request, response);

					}
				} catch (FirmException e) {
					out.println(e.getMessage());
				}

			}

		}
	}

}
