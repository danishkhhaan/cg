package com.cg.sky.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.sky.bean.Bean;
import com.cg.sky.service.SkyService;

@Controller
public class SkyController {
	
		@Autowired
		private SkyService service;

		@RequestMapping("/showFirstPage")
		public String showFirstPage() {
			return "index";
		}

		@RequestMapping("/showViewAll")
		public ModelAndView showViewAll() {
			
			ModelAndView mv = new ModelAndView();
			
			try {
				// System.out.println("message from controller : showViewAll");
				
				// service.getAllDetails();
				List<Bean> list = service.getAllDetails();
				if (list.isEmpty()) {
					// System.out.println("message from controller : list is empty");
					mv.addObject("msg", "There is no customer details");
					mv.setViewName("myError");
				} else {
					// System.out.println("message from controller : list is not empty");
					// System.out.println(list.get(1).getOptionalPack());
					mv.addObject("list", list);
					mv.setViewName("custReport");
				}
				
			} catch(Exception e){
				
			}
			return mv;
		}

		@RequestMapping("/retrieveDetail")
		public ModelAndView retrieveDetail(@RequestParam("custNum") String custNum) {

			ModelAndView mv = new ModelAndView();
			
			try {
	//			System.out.println(custNum);
				Bean bean = new Bean();
				bean = service.getDetail(custNum);
				if (bean != null) {
					mv.addObject("bean", bean);
					mv.setViewName("particularDetails");
				} else {
					mv.addObject("msg", "Select a valid customer number");
					mv.setViewName("myError");
				}
			} catch (Exception e) {
				
			}
			return mv;
		}

}
