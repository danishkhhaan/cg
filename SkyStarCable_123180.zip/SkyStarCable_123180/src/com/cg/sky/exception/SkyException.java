package com.cg.sky.exception;

@SuppressWarnings("serial")
public class SkyException extends Exception{

	public SkyException()
	{
		
	}
	public SkyException(String msg)
	{
		super(msg);
	}
}
