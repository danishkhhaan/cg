package com.cg.sky.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sky.bean.Bean;
import com.cg.sky.dao.SkyDAO;
import com.cg.sky.exception.SkyException;

@Service
public class SkyServiceImpl implements SkyService {

	@Autowired
	SkyDAO dao;

	@Override
	public List<Bean> getAllDetails() throws SkyException {
		// System.out.println("message from service : getAllDetails()");
		// dao.getAllDetails();
		return dao.getAllDetails();
		// return null;
	}

	@Override
	public Bean getDetail(String custNum) throws SkyException {
		return dao.getDetail(custNum);
	}

}
