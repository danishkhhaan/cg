package com.cg.sky.service;

import java.util.List;

import com.cg.sky.bean.Bean;
import com.cg.sky.exception.SkyException;

public interface SkyService {

	List<Bean> getAllDetails() throws SkyException;

	Bean getDetail(String custNum) throws SkyException;

}
