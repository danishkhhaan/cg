package com.cg.sky.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.sky.bean.Bean;
import com.cg.sky.exception.SkyException;

@Repository
public class SkyDAOImpl implements SkyDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Bean> getAllDetails() throws SkyException {
		// System.out.println("message from Dao : getAllDetails()");
		
		TypedQuery<Bean> query = entityManager.createQuery(
				"SELECT d FROM Bean d", Bean.class);
		return query.getResultList();
		// return null;
	}

	@Override
	public Bean getDetail(String custNum) throws SkyException {
		return entityManager.find(Bean.class, custNum);
	}

}
