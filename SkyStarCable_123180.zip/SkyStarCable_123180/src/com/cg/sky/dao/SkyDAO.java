package com.cg.sky.dao;

import java.util.List;

import com.cg.sky.bean.Bean;
import com.cg.sky.exception.SkyException;

public interface SkyDAO {

	List<Bean> getAllDetails() throws SkyException;

	Bean getDetail(String custNum) throws SkyException;

}
